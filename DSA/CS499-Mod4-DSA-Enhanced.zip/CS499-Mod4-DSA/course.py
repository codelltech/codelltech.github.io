"""
course.py

Defines the Course class used to represent a single course.
This class stores course information and formats output for display.
"""

from dataclasses import dataclass, field
from typing import List


@dataclass
class Course:
    """
    Represents a single course with a course number, name, and prerequisites.
    """
    course_number: str
    course_name: str
    prerequisites: List[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        """
        Automatically called after initialization.
        Cleans and standardizes course data.
        """
        # Ensure consistent formatting
        self.course_number = self.course_number.strip().upper()
        self.course_name = self.course_name.strip()

        # Normalize all prerequisite course numbers
        self.prerequisites = [
            prereq.strip().upper() for prereq in self.prerequisites
        ]

    def details(self) -> str:
        """
        Returns a formatted string with full course details.
        """
        if self.prerequisites:
            prereq_text = ", ".join(self.prerequisites)
        else:
            prereq_text = "None"

        return (
            f"{self.course_number}, {self.course_name}\n"
            f"Prerequisites: {prereq_text}"
        )