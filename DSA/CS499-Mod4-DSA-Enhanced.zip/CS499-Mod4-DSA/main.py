"""
main.py

Entry point of the application.
Handles user interaction and menu navigation.
"""

from course_catalog import CourseCatalog


def print_menu() -> None:
    """
    # Displays the main menu options.
    """
    print("\nMenu:")
    print("  1. Load Data Structure")
    print("  2. Print Course List")
    print("  3. Print Course")
    print("  9. Exit")


def load_courses(catalog: CourseCatalog) -> None:
    """
    Prompts the user for a file name and loads course data.
    Includes error handling for invalid files.
    """
    filename = input("Enter file name: ").strip()

    try:
        catalog.load_from_file(filename)
        print("Courses loaded successfully.")
    except FileNotFoundError:
        print(f"Error: Could not open file '{filename}'.")
    except Exception as exc:
        print(f"An unexpected error occurred: {exc}")


def print_course_list(catalog: CourseCatalog) -> None:
    """
    Displays all courses in sorted order.
    """
    if catalog.is_empty():
        print("No courses loaded.")
        return

    print("\nHere is a sample schedule:")
    for course in catalog.get_sorted_courses():
        print(f"{course.course_number}, {course.course_name}")


def print_single_course(catalog: CourseCatalog) -> None:
    """
    Prompts user for a course number and displays details.
    """
    if catalog.is_empty():
        print("No courses loaded.")
        return

    course_number = input("What course do you want to know about? ").strip()
    course = catalog.get_course(course_number)

    if course is None:
        print(f"Course {course_number.upper()} not found.")
    else:
        print()
        print(course.details())


def main() -> None:
    """
    Main program loop.
    Controls user interaction and calls appropriate functions.
    """
    catalog = CourseCatalog()

    print("Welcome to the course planner.")

    while True:
        print_menu()
        choice = input("What would you like to do? ").strip()

        if choice == "1":
            load_courses(catalog)
        elif choice == "2":
            print_course_list(catalog)
        elif choice == "3":
            print_single_course(catalog)
        elif choice == "9":
            print("Thank you for using the course planner!")
            break
        else:
            print(f"{choice} is not a valid option.")


# Ensures the program runs only when executed directly
if __name__ == "__main__":
    main()