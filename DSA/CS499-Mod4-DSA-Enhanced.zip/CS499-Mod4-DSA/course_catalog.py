"""
course_catalog.py

Defines the CourseCatalog class, which manages all course data.
The main data structure is a dictionary.
"""

import csv
from typing import Dict, List, Optional

from course import Course


class CourseCatalog:
    """
    Manages a collection of Course objects using a dictionary.
    The dictionary acts as a hash table where:
        key = course_number
        value = Course object
    """

    def __init__(self) -> None:
        # Initializes an empty course catalog.
        self._courses: Dict[str, Course] = {}

    def add_course(self, course: Course) -> None:
        # Adds a course to the catalog.
        # If the course already exists, it will be overwritten.
        self._courses[course.course_number] = course

    def load_from_file(self, filename: str) -> None:
        """
        Loads course data from a CSV file.

        Expected format:
        courseNumber, courseName, prereq1, prereq2, ...

        Clears existing data before loading new data.
        """
        # Clear existing courses
        self._courses.clear()

        with open(filename, mode="r", newline="", encoding="utf-8") as file:
            reader = csv.reader(file)

            for row in reader:
                # Skip invalid rows
                if len(row) < 2:
                    continue

                course_number = row[0]
                course_name = row[1]

                # Remaining columns are prerequisites (if any)
                prerequisites = row[2:] if len(row) > 2 else []

                # Create Course object and add to catalog
                course = Course(course_number, course_name, prerequisites)
                self.add_course(course)

    def get_course(self, course_number: str) -> Optional[Course]:
        """
        Retrieves a course by its course number.

        Returns:
            Course object if found
            None if not found
        """
        return self._courses.get(course_number.strip().upper())

    def get_sorted_courses(self) -> List[Course]:
        # Returns all courses sorted alphabetically by course number.
        return [self._courses[key] for key in sorted(self._courses.keys())]

    def is_empty(self) -> bool:
        # Checks if the catalog is empty.
        return len(self._courses) == 0