#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Enhanced CRUD module for the AAC MongoDB database.

Enhancements included:
- Input validation for create and update operations
- MongoDB index creation for frequently queried fields
- Aggregation-based reporting helpers
- Stronger error handling and connection management
- Safer credential handling through environment variable overrides
"""

from __future__ import annotations

import os
from typing import Any, Dict, Iterable, List, Optional

from bson.objectid import ObjectId
from pymongo import ASCENDING, MongoClient
from pymongo.collection import Collection
from pymongo.database import Database
from pymongo.errors import PyMongoError


class AnimalShelter:
    """CRUD operations for the AAC animals collection in MongoDB."""

    REQUIRED_FIELDS = {
        "animal_type": str,
        "breed": str,
        "age_upon_outcome_in_weeks": (int, float),
        "outcome_type": str,
    }

    OPTIONAL_STRING_FIELDS = [
        "name",
        "color",
        "sex_upon_outcome",
        "outcome_subtype",
    ]

    def __init__(self, username=None, password=None):
        """
        Initialize connection to local MongoDB.
        """
        HOST = 'localhost'
        PORT = 27017
        DB = 'AAC'
        COL = 'animals'
    
        try:
            self.client = MongoClient(f'mongodb://{HOST}:{PORT}/')
            self.database = self.client[DB]
            self.collection = self.database[COL]
        except PyMongoError as e:
            print(f"Error connecting to MongoDB: {e}")
            raise

    def close(self) -> None:
        """Close the MongoDB connection."""
        if self.client is not None:
            self.client.close()

    def __enter__(self) -> "AnimalShelter":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def ensure_indexes(self) -> List[str]:
        """Create indexes for frequently filtered/reporting fields."""
        if self.collection is None:
            raise ConnectionError("Collection is not initialized.")

        try:
            created = [
                self.collection.create_index([("animal_type", ASCENDING)]),
                self.collection.create_index([("breed", ASCENDING)]),
                self.collection.create_index([("outcome_type", ASCENDING)]),
                self.collection.create_index([("sex_upon_outcome", ASCENDING)]),
                self.collection.create_index([("age_upon_outcome_in_weeks", ASCENDING)]),
            ]
            return created
        except PyMongoError as exc:
            raise RuntimeError(f"Failed to create indexes: {exc}") from exc

    def _validate_record(self, data: Dict[str, Any], partial: bool = False) -> None:
        """Validate record fields before insert or update."""
        if not isinstance(data, dict) or not data:
            raise ValueError("Data must be a non-empty dictionary.")

        for field, expected_type in self.REQUIRED_FIELDS.items():
            if field not in data:
                if partial:
                    continue
                raise ValueError(f"Missing required field: {field}")

            value = data.get(field)
            if value is None or (isinstance(value, str) and not value.strip()):
                raise ValueError(f"Field '{field}' cannot be empty.")
            if not isinstance(value, expected_type):
                raise TypeError(
                    f"Field '{field}' must be of type {expected_type}, got {type(value).__name__}."
                )

        age_value = data.get("age_upon_outcome_in_weeks")
        if age_value is not None:
            if age_value < 0:
                raise ValueError("age_upon_outcome_in_weeks must be greater than or equal to 0.")

        for field in self.OPTIONAL_STRING_FIELDS:
            if field in data and data[field] is not None and not isinstance(data[field], str):
                raise TypeError(f"Field '{field}' must be a string when provided.")

    def create(self, data: Dict[str, Any]) -> Optional[str]:
        """Insert a document after validation. Returns the inserted id as a string."""
        if self.collection is None:
            raise ConnectionError("Collection is not initialized.")

        self._validate_record(data)

        try:
            result = self.collection.insert_one(data)
            return str(result.inserted_id)
        except PyMongoError as exc:
            print(f"Insert failed: {exc}")
            return None

    def read(
        self,
        query: Optional[Dict[str, Any]] = None,
        projection: Optional[Dict[str, int]] = None,
        sort: Optional[Iterable] = None,
        limit: int = 0,
    ) -> List[Dict[str, Any]]:
        """Read documents with optional projection, sort, and limit."""
        if self.collection is None:
            raise ConnectionError("Collection is not initialized.")

        if query is None:
            query = {}

        try:
            cursor = self.collection.find(query, projection)
            if sort:
                cursor = cursor.sort(list(sort))
            if limit and limit > 0:
                cursor = cursor.limit(limit)
            return list(cursor)
        except PyMongoError as exc:
            print(f"Read error: {exc}")
            return []

    def update(self, query: Dict[str, Any], update_data: Dict[str, Any]) -> int:
        """Update matching documents after validating the new field values."""
        if self.collection is None:
            raise ConnectionError("Collection is not initialized.")

        if not query:
            raise ValueError("Query must not be empty for update operations.")
        if not update_data:
            raise ValueError("Update data must not be empty.")

        self._validate_record(update_data, partial=True)

        try:
            result = self.collection.update_many(query, {"$set": update_data})
            return result.modified_count
        except PyMongoError as exc:
            print(f"Update failed: {exc}")
            return 0

    def delete(self, query: Dict[str, Any]) -> int:
        """Delete matching documents."""
        if self.collection is None:
            raise ConnectionError("Collection is not initialized.")

        if not query:
            raise ValueError("Query must not be empty for delete operations.")

        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except PyMongoError as exc:
            print(f"Delete failed: {exc}")
            return 0

    def aggregate_summary(
        self,
        group_field: str,
        match: Optional[Dict[str, Any]] = None,
        limit: int = 10,
    ) -> List[Dict[str, Any]]:
        """Summarize records by a selected field using MongoDB aggregation."""
        if self.collection is None:
            raise ConnectionError("Collection is not initialized.")

        if not group_field:
            raise ValueError("group_field is required.")

        pipeline: List[Dict[str, Any]] = []
        if match:
            pipeline.append({"$match": match})

        pipeline.extend(
            [
                {
                    "$group": {
                        "_id": f"${group_field}",
                        "count": {"$sum": 1},
                    }
                },
                {"$project": {"_id": 0, group_field: {"$ifNull": ["$_id", "Unknown"]}, "count": 1}},
                {"$sort": {"count": -1}},
                {"$limit": limit},
            ]
        )

        try:
            return list(self.collection.aggregate(pipeline))
        except PyMongoError as exc:
            print(f"Aggregation failed: {exc}")
            return []

    def get_outcome_report(self, match: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """Convenience method for reporting animals by outcome type."""
        return self.aggregate_summary("outcome_type", match=match, limit=20)

    def get_breed_report(self, match: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """Convenience method for reporting animals by breed."""
        return self.aggregate_summary("breed", match=match, limit=20)


if __name__ == "__main__":
    try:
        with AnimalShelter() as shelter:
            print("Connected successfully.")
            print("Indexes ensured:", shelter.ensure_indexes())
    except Exception as exc:
        print(exc)
